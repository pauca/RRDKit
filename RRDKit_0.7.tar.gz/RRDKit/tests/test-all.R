library(testthat)
library(RRDKit)

test_package("RRDKit")
